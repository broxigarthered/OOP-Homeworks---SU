﻿namespace Empires.Interfaces
{
    public enum ResourceType
    {
        Gold,
        Steel
    }
}