﻿namespace Empires.Interfaces
{
    public interface IExecutable
    {
        void Execute();
    }
}